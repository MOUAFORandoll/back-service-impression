<?php

namespace Database\Seeders;

use App\Models\Abonnement;
use Illuminate\Database\Seeder;

class AbonnementSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [

            ['libelle' => 'type 1', 'libelle_en' => 'type 1', "duree" => 30, "prix" => 1000],
            ['libelle' => 'type 2', 'libelle_en' => 'type 2', "duree" => 60, "prix" => 1700],
            ['libelle' => 'type 3', 'libelle_en' => 'type 3', "duree" => 90, "prix" => 2500]

        ];


        for ($i = 0; $i < count($data); $i++) {
            Abonnement::create([
                'libelle' => $data[$i]['libelle'],
                'libelle_en' => $data[$i]['libelle_en'],
                'duree' => $data[$i]['duree'],
                'prix' => $data[$i]['prix'],


            ]);
        }
    }
}
