<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAbonnementLicenceAlerteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('abonnements', function (Blueprint $table) {
            $table->id();
            $table->string('libelle');
            $table->string('libelle_en');
            $table->bigInteger('duree');
            $table->float('prix');
            $table->timestamps();
            $table->softDeletes();
        });
        Schema::create('licence_alertes', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('user_id');

            $table->unsignedBigInteger('abonnement_id')->nullable();
            $table->foreign('abonnement_id')
                ->references('id')
                ->on('abonnements')
                ->onDelete('RESTRICT')
                ->onUpdate('RESTRICT');
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('licence_alertes');
        Schema::dropIfExists(
            'abonnements'
        );
    }
}
