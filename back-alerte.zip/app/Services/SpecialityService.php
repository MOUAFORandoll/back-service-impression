<?php

namespace App\Services;

use App\Models\Agenda;
use App\Models\Etablissement;
use App\Models\SpecialiteEtablissement;
use App\Models\Localisation;
use Illuminate\Http\Request;
use App\Models\NotationPatient;
use App\Models\Patient;
use App\Models\Specialite;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Str;

class SpecialityService
{
    public function __construct()
    {
    }

    public function index(Request $request)
    {
        
    }
}
