<?php

namespace App\Http\Controllers;

class MyController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }
    function searchDataMapByName($key)
    {
    }
    //
}
