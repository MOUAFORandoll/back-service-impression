<?php

namespace App\Http\Controllers\v1;

use App\Models\Categorie;
use App\Models\CategorieEtablissement;
use App\Models\SpecialiteEtablissement;
use App\Services\AbonnemetLicenceAlerteService;
use App\Services\NotationService;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Alerte;
use App\Models\Etablissement;
use App\Models\NotationPatient;
use App\Models\Patient;
use App\Models\Specialite;
use App\Services\AlerteService;
use Carbon\Carbon;
use Nette\Utils\DateTime;

class LicenceController extends Controller
{

    private $abonnemetLicenceAlerteService;

    public function __construct(AbonnemetLicenceAlerteService  $abonnemetLicenceAlerteService)
    {

        $this->abonnemetLicenceAlerteService = $abonnemetLicenceAlerteService;
    }

    public function index(Request $request)
    {
        // $size = $request->size ?? 25;
        // $user_id = $request->user_id;
        // $alertes = Alerte::query();
        // if ($user_id != "") {
        //     $alertes = $alertes->where('user_id', $user_id)->with(['etablissement'])->whereNotNull('etablissement_id');
        // }
        // $alertes = $alertes->with(['etablissement.localisation', 'specialites'])->latest()->paginate($size);
        // return $this->successResponse($alertes);
    }
    public function indexAbonnement(Request $request)
    {

        $listAbonnement
            =  $this->abonnemetLicenceAlerteService->indexAbonnement($request);
        return $this->successResponse($listAbonnement);
    }
    /**
     * Show the form for creating a new resource or update if existing .
     *
     * @return        \Illuminate\Http\JsonResponse

     */
    public function storeAbonnement(Request $request)
    {


        $this->validate($request, [
            'libelle' => 'required',
            'libelle_en' =>
            'required',
            'duree' =>
            'required',
            'prix' => 'required',

        ]);
        $result
            =  $this->abonnemetLicenceAlerteService->storeAbonnement($request);


        return $this->successResponse($result);
    }




    public function hasValidLicenceAlerteUser($user_id)
    {
        $result
            =  $this->abonnemetLicenceAlerteService->hasValidLicenceAlerteUser($user_id);


        return $this->successResponse($result);
    }

    public function getListLicenceAlerteUser(Request $request, $user_id)
    {
        $result
            =  $this->abonnemetLicenceAlerteService->getListLicenceAlerteUser($request, $user_id);


        return $this->successResponse($result);
    }

    /**
     * Show the form for creating a new resource or update if existing .
     *
     * @return        \Illuminate\Http\JsonResponse

     */
    public function buyLicenceAlerte(Request $request)
    {
        $this->validate($request, [
            'user_id' => 'required|integer',
            'abonnement_id' => 'required|integer',



        ]);
        $result
            =  $this->abonnemetLicenceAlerteService->buyLicenceAlerte($request);


        return $this->successResponse($result);
    }
}
