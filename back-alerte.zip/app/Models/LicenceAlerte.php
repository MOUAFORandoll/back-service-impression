<?php

namespace App\Models;


use App\Models\Etablissement;
use App\Models\Specialite;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class LicenceAlerte extends Model
{
    use HasFactory, SoftDeletes;


    protected $fillable = [
        "user_id",
        "abonnement_id",

    ]; 
    public function Abonnement()
    {
        return $this->belongsTo(Abonnement::class, 'abonnement_id', 'id');
    }
}
