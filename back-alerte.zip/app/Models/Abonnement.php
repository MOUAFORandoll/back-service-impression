<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Abonnement extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = ["libelle", "libelle_en", "duree", "prix"];



    public function LicenceAlerte()
    {
        return $this->hasMany(LicenceAlerte::class, 'abonnement_id');
    }
}
