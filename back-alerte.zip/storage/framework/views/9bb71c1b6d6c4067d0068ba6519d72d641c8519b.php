<?php $__env->startComponent('mail::message'); ?>
# Medsurlink

Bonjour j'ai ajoute mon etablissement a medsurlink
<br>Je demande une activation rapide de mon etablissement
<strong><?php echo e($etablissement->name); ?></strong><br><br>



<div class="div-logo-mail">
    <img class="logo-footer" src="https://www.back.medsurlink.com/images/logo.png" alt="Logo-Medicasure">
</div>

<a href="<?php echo e(config('app.frontend_url')); ?>" class="logo-footer center"> Medsurlink </a>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\Dev\Medsur\back-alerte\resources\views/emails/activate-etablissement.blade.php ENDPATH**/ ?>