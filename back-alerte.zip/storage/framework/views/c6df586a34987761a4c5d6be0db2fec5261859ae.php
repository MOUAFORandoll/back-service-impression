<?php echo e($slot); ?>

<?php /**PATH C:\Dev\Medsur\back-alerte\vendor\illuminate\mail/resources/views/text/footer.blade.php ENDPATH**/ ?>