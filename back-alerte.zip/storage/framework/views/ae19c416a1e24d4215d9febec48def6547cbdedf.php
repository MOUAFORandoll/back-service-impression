[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Dev\Medsur\back-alerte\vendor\illuminate\mail/resources/views/text/header.blade.php ENDPATH**/ ?>